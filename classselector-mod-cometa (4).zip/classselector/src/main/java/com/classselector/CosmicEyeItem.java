package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;

import java.util.List;

/** Olho Cósmico: clique direito em um Warden para domá-lo. */
public class CosmicEyeItem extends Item {
    public CosmicEyeItem() {
        super(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof Warden warden)) return InteractionResult.PASS;
        Level lv = player.level();
        if (!lv.isClientSide) {
            if (TamedWarden.isTamed(warden)) {
                player.displayClientMessage(Component.literal("Este Warden já foi domado."), true);
            } else {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                if (warden.getRandom().nextFloat() < TamedWarden.TAME_CHANCE) {
                    TamedWarden.tame(warden, player);
                } else {
                    TamedWarden.failTame(warden, player);
                }
            }
        }
        return InteractionResult.sidedSuccess(lv.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("item.classselector.cosmic_eye.lore1").withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("item.classselector.cosmic_eye.lore2")
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }
}

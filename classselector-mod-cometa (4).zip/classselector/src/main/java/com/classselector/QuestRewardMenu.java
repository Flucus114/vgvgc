package com.classselector;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** Baú onde o OP coloca os itens de recompensa da quest. */
public class QuestRewardMenu extends ChestMenu {
    private final String questId;
    private final SimpleContainer box;

    public static void open(ServerPlayer p, QuestDef def) {
        SimpleContainer box = new SimpleContainer(27);
        for (int i = 0; i < def.rewards.size() && i < 27; i++) box.setItem(i, def.rewards.get(i).copy());
        p.openMenu(new SimpleMenuProvider(
                (id, inv, pl) -> new QuestRewardMenu(id, inv, box, def.id),
                Component.literal("Recompensa: " + def.name)));
    }

    private QuestRewardMenu(int id, Inventory inv, SimpleContainer box, String questId) {
        super(MenuType.GENERIC_9x3, id, inv, box, 3);
        this.box = box;
        this.questId = questId;
    }

    @Override
    public void removed(Player pl) {
        super.removed(pl);
        if (!(pl instanceof ServerPlayer sp)) return;
        QuestData data = QuestData.get(sp.server);
        QuestDef q = data.quests.get(questId);
        if (q == null) return;
        q.rewards.clear();
        for (int i = 0; i < box.getContainerSize(); i++) {
            ItemStack s = box.getItem(i);
            if (!s.isEmpty()) q.rewards.add(s.copy());
        }
        data.setDirty();
        QuestManager.syncAll(sp.server);
    }
}

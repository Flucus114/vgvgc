package com.classselector;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;

import java.util.function.Supplier;

/** Remove do loot de baús e de bosses os itens da lista do /lootpurge. */
public class PurgeLootModifier extends LootModifier {
    public static final Supplier<Codec<PurgeLootModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, PurgeLootModifier::new)));

    public PurgeLootModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext ctx) {
        MinecraftServer server = ctx.getLevel().getServer();
        if (server == null || loot.isEmpty()) return loot;
        RestrictionData d = RestrictionData.get(server);
        if (d.purge.isEmpty()) return loot;
        if (!isChestLoot(ctx) && !isBossLoot(ctx, d)) return loot;
        loot.removeIf(d::isPurged);
        return loot;
    }

    private static boolean isBossLoot(LootContext ctx, RestrictionData d) {
        Entity e = ctx.getParamOrNull(LootContextParams.THIS_ENTITY);
        return e != null && d.isBoss(e);
    }

    private static boolean isChestLoot(LootContext ctx) {
        ResourceLocation id = ctx.getQueriedLootTableId();
        if (id != null) {
            String p = id.getPath();
            if (p.startsWith("chests/") || p.contains("/chests/")) return true;
            if (p.startsWith("entities/") || p.startsWith("blocks/") || p.startsWith("gameplay/")
                    || p.startsWith("archaeology/")) return false;
        }
        // tabelas de mods com outros nomes: contexto de "baú" (origem, sem ferramenta/bloco/dano)
        if (!ctx.hasParam(LootContextParams.ORIGIN) || ctx.hasParam(LootContextParams.TOOL)
                || ctx.hasParam(LootContextParams.BLOCK_STATE) || ctx.hasParam(LootContextParams.DAMAGE_SOURCE)) {
            return false;
        }
        Entity e = ctx.getParamOrNull(LootContextParams.THIS_ENTITY);
        return e == null || e instanceof Player;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}

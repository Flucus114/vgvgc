package com.classselector;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

/**
 * Soberano Cósmico: boss voador com 3 ataques.
 *  1) Cometas cósmicos (projéteis 3D roxos; na fase 2 também um cometa teleguiado)
 *  2) Pulso gravitacional (onda de choque em área, empurra e machuca)
 *  3) Raio cósmico (só na fase 2, com aviso antes de disparar)
 * Fase 2 começa com menos de 50% de vida.
 */
public class CosmicBoss extends Monster {
    private static final EntityDataAccessor<Integer> DATA_ATTACK =
            SynchedEntityData.defineId(CosmicBoss.class, EntityDataSerializers.INT);
    /** Tempo (ticks) desde o início do ataque atual; 0 = sem ataque. Usado pela animação de arremesso. */
    private static final EntityDataAccessor<Integer> DATA_ATK_TICK =
            SynchedEntityData.defineId(CosmicBoss.class, EntityDataSerializers.INT);

    /** Escala do modelo e caixa de colisão (blocos). Ao mudar o tamanho, ajuste os dois. */
    public static final float SCALE = 2.4F;
    public static final float WIDTH = 9.0F, HEIGHT = 15.6F;
    /** Fator em relação ao tamanho original (escala 1,6): as distâncias do combate acompanham o tamanho. */
    public static final double K = SCALE / 1.6D;
    /** Altura máxima de voo: no máximo este número de blocos acima do chão. */
    public static final double MAX_FLY_HEIGHT = 5.0D, MIN_FLY_HEIGHT = 1.0D;

    public static final int ATK_NONE = 0, ATK_ORBS = 1, ATK_PULSE = 2, ATK_BEAM = 3;

    /** Ticks (desde o início do ataque) em que cada cometa sai. O índice par usa a mão P, o ímpar a mão N. */
    public static final int[] ORB_SHOTS_1 = {18, 26, 34};
    public static final int[] ORB_SHOTS_2 = {18, 24, 30, 36, 42};
    /** Duração (ticks) da preparação do braço antes de cada arremesso e da soltura depois dele. */
    public static final int THROW_WINDUP = 9, THROW_RELEASE = 7;

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.classselector.cosmic_sovereign"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    /** Só no cliente: pesos suavizados (parado, orbes, pulso, raio) usados pelo modelo. */
    private final float[] poseWeights = {1.0F, 0.0F, 0.0F, 0.0F};
    private boolean phase2Announced = false;

    public CosmicBoss(EntityType<? extends CosmicBoss> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 10, true);
        this.xpReward = 500;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.45D)
                .add(Attributes.FLYING_SPEED, 0.55D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ATTACK, ATK_NONE);
        this.entityData.define(DATA_ATK_TICK, 0);
    }

    public int getAttack() { return this.entityData.get(DATA_ATTACK); }
    private void setAttack(int a) { this.entityData.set(DATA_ATTACK, a); }
    public int getAtkTick() { return this.entityData.get(DATA_ATK_TICK); }
    private void setAtkTick(int t) { this.entityData.set(DATA_ATK_TICK, t); }

    /**
     * Posição aproximada da mão que arremessa (braço 0 = P, 1 = N), igual à do modelo com os braços erguidos.
     * Usada como ponto de saída dos cometas e das partículas de carga.
     */
    public static Vec3 handPos(CosmicBoss b, int arm) {
        double yaw = Math.toRadians(b.getYRot());
        double side = arm == 0 ? 1.0D : -1.0D;
        return new Vec3(
                b.getX() - Math.sin(yaw) * 3.0D * K + Math.cos(yaw) * 1.7D * K * side,
                b.getY() + 6.0D * K,
                b.getZ() + Math.cos(yaw) * 3.0D * K + Math.sin(yaw) * 1.7D * K * side);
    }
    public float[] getPoseWeights() { return poseWeights; }
    public boolean isPhase2() { return getHealth() < getMaxHealth() * 0.5F; }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new CombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Altura (Y) do topo do primeiro bloco sólido abaixo de {@code fromY} na coluna (x, z); procura até 40 blocos. */
    public double groundYAt(double x, double z, double fromY) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(Mth.floor(x), Mth.floor(fromY), Mth.floor(z));
        int min = level().getMinBuildHeight();
        for (int i = 0; i < 40 && p.getY() > min; i++) {
            if (!level().getBlockState(p).getCollisionShape(level(), p).isEmpty()) return p.getY() + 1.0D;
            p.setY(p.getY() - 1);
        }
        return fromY - 40.0D;   // sem chão por perto: considera-o bem abaixo (puxa o boss para baixo)
    }

    /** Mantém o boss a no máximo MAX_FLY_HEIGHT blocos do chão. */
    private void limitFlightHeight() {
        double gy = groundYAt(getX(), getZ(), getY() + 1.0D);
        double over = getY() - (gy + MAX_FLY_HEIGHT);
        if (over <= 0.0D) return;
        Vec3 dm = getDeltaMovement();
        if (over < 1.0D) {
            setPos(getX(), gy + MAX_FLY_HEIGHT, getZ());
            if (dm.y > 0.0D) setDeltaMovement(dm.x, 0.0D, dm.z);
        } else {
            setDeltaMovement(dm.x, Math.min(dm.y, -0.5D), dm.z);   // desce até a faixa permitida
        }
    }

    // ---------- física de voador ----------
    @Override public boolean isNoGravity() { return true; }
    @Override public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }
    @Override protected void checkFallDamage(double y, boolean onGround, net.minecraft.world.level.block.state.BlockState s, net.minecraft.core.BlockPos p) { }
    @Override public boolean isPushedByFluid() { return false; }
    @Override public boolean canBeLeashed(Player p) { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override protected float getStandingEyeHeight(Pose pose, EntityDimensions dim) { return 8.0F * (float) K; }

    @Override
    public boolean isInvulnerableTo(DamageSource s) {
        return s.getEntity() == this || s.is(DamageTypes.IN_WALL) || s.is(DamageTypes.DROWN)
                || s.is(DamageTypes.FALL) || super.isInvulnerableTo(s);
    }

    // ---------- barra de boss ----------
    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        this.bossEvent.addPlayer(p);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        this.bossEvent.removePlayer(p);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        if (isPhase2() && !phase2Announced) {
            phase2Announced = true;
            this.playSound(SoundEvents.ENDER_DRAGON_GROWL, 4.0F, 0.7F);
            ((ServerLevel) level()).sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 6.0 * K, getZ(), 200, 3.5 * K, 3.5 * K, 3.5 * K, 0.4);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) limitFlightHeight();
        // sempre de frente para o alvo (o controle de voo viraria para a direção do movimento)
        LivingEntity t = getTarget();
        if (!level().isClientSide && t != null) {
            float yaw = (float) (Mth.atan2(t.getZ() - getZ(), t.getX() - getX()) * 57.2957795D) - 90.0F;
            float diff = Mth.wrapDegrees(yaw - getYRot());
            setYRot(getYRot() + Mth.clamp(diff, -10.0F, 10.0F));
            this.yBodyRot = getYRot();
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) {
            int a = getAttack();
            for (int i = 0; i < 4; i++) {
                float target = (i == a) ? 1.0F : 0.0F;
                poseWeights[i] += (target - poseWeights[i]) * 0.15F;
            }
            if (isAlive()) {
                level().addParticle(ParticleTypes.PORTAL, getRandomX(1.0D), getRandomY(), getRandomZ(1.0D),
                        (random.nextDouble() - 0.5D) * 0.5D, -random.nextDouble() * 0.5D, (random.nextDouble() - 0.5D) * 0.5D);
            }
        }
    }

    // ---------- sons ----------
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENDERMAN_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENDERMAN_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENDER_DRAGON_DEATH; }

    // ---------- drops ----------
    @Override
    protected void dropCustomDeathLoot(DamageSource src, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(src, looting, recentlyHit);
        spawnAtLocation(new ItemStack(Items.NETHER_STAR));
        spawnAtLocation(new ItemStack(Items.ENDER_PEARL, 8 + random.nextInt(9)));
        spawnAtLocation(new ItemStack(Items.AMETHYST_SHARD, 24 + random.nextInt(25)));
    }

    // =====================================================================
    //  IA de combate: voa em volta do alvo e alterna entre os ataques
    // =====================================================================
    static class CombatGoal extends Goal {
        private final CosmicBoss boss;
        private int attackType = ATK_NONE;
        private int attackTicks = 0;
        private int cooldown = 50;
        private int moveTimer = 0;
        private Vec3 dest;
        private Vec3 aimDir;

        CombatGoal(CosmicBoss boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override public boolean canUse() {
            LivingEntity t = boss.getTarget();
            return t != null && t.isAlive();
        }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void start() { cooldown = 40; attackType = ATK_NONE; }
        @Override public void stop() { boss.setAttack(ATK_NONE); boss.setAtkTick(0); attackType = ATK_NONE; }
        @Override public boolean requiresUpdateEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity t = boss.getTarget();
            if (t == null) return;
            boss.getLookControl().setLookAt(t, 30.0F, 30.0F);

            boolean stationary = attackType == ATK_PULSE || attackType == ATK_BEAM;
            if (stationary) {
                boss.getMoveControl().setWantedPosition(boss.getX(), boss.getY(), boss.getZ(), 0.1D);
            } else {
                if (--moveTimer <= 0 || boss.horizontalCollision
                        || (dest != null && boss.position().distanceToSqr(dest) < 4.0D)) {
                    pickDestination(t);
                    moveTimer = 30 + boss.random.nextInt(30);
                }
                if (dest != null) boss.getMoveControl().setWantedPosition(dest.x, dest.y, dest.z, 1.0D);
            }

            if (attackType == ATK_NONE) {
                if (--cooldown <= 0) chooseAttack(t);
            } else {
                attackTicks++;
                switch (attackType) {
                    case ATK_ORBS -> runOrbs(t);
                    case ATK_PULSE -> runPulse();
                    case ATK_BEAM -> runBeam(t);
                    default -> { }
                }
            }
            boss.setAtkTick(attackType == ATK_NONE ? 0 : attackTicks);   // sincroniza a animação com o cliente
        }

        private void pickDestination(LivingEntity t) {
            double ang = boss.random.nextDouble() * Math.PI * 2.0D;
            double dist = (boss.isPhase2() ? 13.0D + boss.random.nextDouble() * 5.0D : 16.0D + boss.random.nextDouble() * 6.0D) * K;
            double dx = t.getX() + Math.cos(ang) * dist, dz = t.getZ() + Math.sin(ang) * dist;
            double wantY = t.getY() + 0.5D + boss.random.nextDouble() * 2.0D;
            // nunca voa a mais de MAX_FLY_HEIGHT blocos do chão (nem rente demais a ele)
            double gy = boss.groundYAt(dx, dz, Math.max(wantY, t.getY()) + 2.0D);
            double y = Mth.clamp(wantY, gy + MIN_FLY_HEIGHT, gy + MAX_FLY_HEIGHT);
            dest = new Vec3(dx, y, dz);
        }

        private void chooseAttack(LivingEntity t) {
            double d = boss.distanceTo(t);
            float r = boss.random.nextFloat();
            int type;
            if (d < 18.0D && r < 0.6F) type = ATK_PULSE;
            else if (boss.isPhase2() && r < 0.45F) type = ATK_BEAM;
            else type = ATK_ORBS;
            attackType = type;
            attackTicks = 0;
            aimDir = null;
            boss.setAttack(type);
        }

        private void finish() {
            attackType = ATK_NONE;
            attackTicks = 0;
            cooldown = boss.isPhase2() ? 40 : 70;
            boss.setAttack(ATK_NONE);
        }

        // ---------- 1) orbes ----------
        private void runOrbs(LivingEntity t) {
            boolean p2 = boss.isPhase2();
            int[] shots = p2 ? ORB_SHOTS_2 : ORB_SHOTS_1;
            ServerLevel sl = (ServerLevel) boss.level();
            for (int i = 0; i < shots.length; i++) {
                int s = shots[i];
                int arm = i & 1;
                // preparação: energia é sugada para a mão que vai arremessar
                if (attackTicks == s - THROW_WINDUP) boss.playSound(SoundEvents.AMETHYST_BLOCK_RESONATE, 2.5F, 0.6F);
                if (attackTicks > s - THROW_WINDUP && attackTicks < s) {
                    Vec3 h = handPos(boss, arm);
                    sl.sendParticles(ParticleTypes.PORTAL, h.x, h.y, h.z, 5, 0.9, 0.9, 0.9, 0.4);
                }
                if (attackTicks == s) {
                    fireOrb(t, arm);
                    if (p2 && s == 30) fireHoming(t, arm);
                }
            }
            if (attackTicks > 52) finish();
        }

        private void fireOrb(LivingEntity t, int arm) {
            Level lv = boss.level();
            Vec3 o = handPos(boss, arm);
            double dx = t.getX() - o.x + (boss.random.nextDouble() - 0.5D) * 3.0D;
            double dy = t.getY(0.5D) - o.y;
            double dz = t.getZ() - o.z + (boss.random.nextDouble() - 0.5D) * 3.0D;
            lv.addFreshEntity(CosmicComet.create(lv, boss, o, new Vec3(dx, dy, dz)));
            ((ServerLevel) lv).sendParticles(ParticleTypes.END_ROD, o.x, o.y, o.z, 14, 0.4, 0.4, 0.4, 0.12);
            boss.playSound(SoundEvents.ENDER_DRAGON_SHOOT, 2.0F, 1.0F);
        }

        private void fireHoming(LivingEntity t, int arm) {
            Level lv = boss.level();
            lv.addFreshEntity(CosmicComet.createHoming(lv, boss, handPos(boss, arm), t));
            boss.playSound(SoundEvents.SHULKER_SHOOT, 2.0F, 0.8F);
        }

        // ---------- 2) pulso gravitacional ----------
        private void runPulse() {
            ServerLevel sl = (ServerLevel) boss.level();
            if (attackTicks == 1) boss.playSound(SoundEvents.ENDER_DRAGON_GROWL, 3.0F, 0.9F);
            if (attackTicks < 30) {
                sl.sendParticles(ParticleTypes.PORTAL, boss.getX(), boss.getY() + 5.5D * K, boss.getZ(), 18, 3.5 * K, 2.5 * K, 3.5 * K, 0.5);
            } else if (attackTicks == 30) {
                double radius = boss.isPhase2() ? 19.0D : 17.0D;
                float dmg = boss.isPhase2() ? 22.0F : 16.0F;
                boss.playSound(SoundEvents.GENERIC_EXPLODE, 4.0F, 0.6F);
                for (LivingEntity e : boss.level().getEntitiesOfClass(LivingEntity.class,
                        boss.getBoundingBox().inflate(radius, 10.0D * K, radius),
                        x -> x != boss && x.isAlive() && boss.distanceToSqr(x) <= radius * radius)) {
                    e.hurt(boss.damageSources().mobAttack(boss), dmg);
                    double dx = e.getX() - boss.getX(), dz = e.getZ() - boss.getZ();
                    double len = Math.sqrt(dx * dx + dz * dz);
                    if (len < 0.01D) { dx = 1.0D; dz = 0.0D; len = 1.0D; }
                    e.push(dx / len * 1.6D, 0.8D, dz / len * 1.6D);
                    e.hurtMarked = true;
                }
                for (double r = 2.0D; r <= radius; r += 2.0D) {
                    for (int i = 0; i < 16; i++) {
                        double a = i * Math.PI / 8.0D;
                        sl.sendParticles(ParticleTypes.END_ROD, boss.getX() + Math.cos(a) * r, boss.getY() + 0.6D,
                                boss.getZ() + Math.sin(a) * r, 1, 0.0, 0.1, 0.0, 0.05);
                    }
                }
                sl.sendParticles(ParticleTypes.REVERSE_PORTAL, boss.getX(), boss.getY() + 4.0D * K, boss.getZ(), 180, 2.0 * K, 2.0 * K, 2.0 * K, 0.6);
            }
            if (attackTicks > 42) finish();
        }

        // ---------- 3) raio cósmico (fase 2) ----------
        private void runBeam(LivingEntity t) {
            ServerLevel sl = (ServerLevel) boss.level();
            Vec3 eye = boss.getEyePosition();
            if (attackTicks == 1) boss.playSound(SoundEvents.BEACON_ACTIVATE, 3.0F, 0.6F);
            if (attackTicks < 38) {
                sl.sendParticles(ParticleTypes.END_ROD, eye.x, eye.y, eye.z, 4, 0.8, 0.8, 0.8, 0.05);
            }
            if (attackTicks == 38) {
                aimDir = t.getBoundingBox().getCenter().subtract(eye).normalize();
            }
            if (aimDir != null && attackTicks > 38 && attackTicks < 45) {
                drawLine(sl, eye, 1.0D);   // aviso: linha fina antes do disparo
            }
            if (aimDir != null && attackTicks >= 45 && attackTicks <= 57 && (attackTicks - 45) % 3 == 0) {
                if (attackTicks == 45) boss.playSound(SoundEvents.END_PORTAL_SPAWN, 3.0F, 1.4F);
                fireBeam(sl, eye);
            }
            if (attackTicks > 66) finish();
        }

        private double beamLength(ServerLevel sl, Vec3 eye) {
            Vec3 to = eye.add(aimDir.scale(45.0D));
            BlockHitResult hit = sl.clip(new ClipContext(eye, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, boss));
            return eye.distanceTo(hit.getLocation());
        }

        private void drawLine(ServerLevel sl, Vec3 eye, double step) {
            double len = beamLength(sl, eye);
            for (double d = 1.0D; d <= len; d += step * 2.0D) {
                Vec3 p = eye.add(aimDir.scale(d));
                sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }

        private void fireBeam(ServerLevel sl, Vec3 eye) {
            double len = beamLength(sl, eye);
            Set<LivingEntity> hit = new HashSet<>();
            for (double d = 1.0D; d <= len; d += 1.0D) {
                Vec3 p = eye.add(aimDir.scale(d));
                sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 0.15, 0.15, 0.15, 0.02);
                sl.sendParticles(ParticleTypes.PORTAL, p.x, p.y, p.z, 3, 0.3, 0.3, 0.3, 0.2);
                hit.addAll(sl.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(1.0D),
                        x -> x != boss && x.isAlive()));
            }
            for (LivingEntity e : hit) e.hurt(boss.damageSources().indirectMagic(boss, boss), 20.0F);
        }
    }
}
